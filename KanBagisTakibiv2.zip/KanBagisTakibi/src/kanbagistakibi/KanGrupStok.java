/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package kanbagistakibi;
import java.util.Scanner;

/**
 *
 * @author ofbahar
 */
public class KanGrupStok {  
    
    Scanner scan = new Scanner(System.in);
    String[] kanGruplari = {"Arh+","Brh+","ABrh+","0rh+","Arh-","Brh-","ABrh-","0rh-"};        
    public int[] unitestok = {30,30,30,30,30,30,30,30};
        
    void MenuYaz(){
            
        for(int i = 0;i<kanGruplari.length;i++)
            System.out.format("[%d] --> %s\n", i,kanGruplari[i]);
            
    }
               
    
    void StokDurumuGoster(){
        
        MenuYaz();        
        System.out.println("Stok durumu goruntulemek icin secim yapiniz : ");        
        int secim = scan.nextInt();
        
        do{       
        
            if(secim >= 0 && secim <= 7)
                System.out.format("%s kan grubu stok miktari : %d adet",kanGruplari[secim],this.unitestok[secim]);
            
            else
                break;
            
        }while(!(secim >= 0 && secim <= 7));
        
        if(!(secim >= 0 && secim <= 7))
            System.out.println("Yanlis secim yaptiniz!");
    }
        
            
    void KanEkle(){
        
        MenuYaz();
        System.out.println("Kan grubu stok ikmali icin secim yapiniz : ");        
        int secim = scan.nextInt();
        
        do{       
        
            if(secim >= 0 && secim <= 7){
                System.out.format("%s kan grubu stok miktari : %d adet\n",kanGruplari[secim],unitestok[secim]);
                System.out.format("%s Kan grubuna kac unite kan eklenecek : ",kanGruplari[secim]);
                int unite = scan.nextInt();
                this.unitestok[secim]+=unite;
                System.out.println("Ekleme islemi basariyla tamamlandi! Güncel stok durumu : "+this.unitestok[secim]+" unite");
            }
            else{
                break;
            }
            
        }while(!(secim >= 0 && secim <= 7));
        
        if(!(secim >= 0 && secim <= 7))
            System.out.println("Yanlis secim yaptiniz!");
        
        
        
    }
    
    void KanKullan(int unite,String kan){
                       
        for(int i=0;i<7;i++){
            
            if(kan.equals(kanGruplari[i])){
                this.unitestok[i]-=unite;
                System.out.println("Kullanma islemi basariyla tamamlandi! "+kanGruplari[i]+" Kan grubu güncel stok durumu : "+this.unitestok[i]+" unite");
                break;
            }
            
        } 
        
    }
    
    void uyari(){
        
        System.out.println("\n");
        for(int i=0;i<this.unitestok.length;i++){
            
            if(this.unitestok[i]<20)
                System.out.println(kanGruplari[i] + " Kan grubu kritik seviyede azalmistir! Lutfen ikmal yapiniz. Kalan unite : "+this.unitestok[i]+"\n");
            
        }
        
    }
      
        
}
            
    
    

