/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package kanbagistakibi;

import java.util.ArrayList;
import java.util.Scanner;
import java.util.concurrent.TimeUnit;

/**
 *
 * @author ofbahar
 */
public class KanBagisTakibi {

    /**
     * @param args the command line arguments
     * @throws java.lang.InterruptedException
     */
    public static void main(String[] args) throws InterruptedException {
        // TODO code application logic here
            
        Hastalar hasta = new Hastalar();
        AcilHasta acil = new AcilHasta();
        KanGrupStok stokislem = new KanGrupStok();
        Scanner input = new Scanner(System.in);
        ArrayList idler = new ArrayList();
        
        acil.ilkHastalar();
        hasta.ilkHastalar();    
        
        int secim = MenuGetir();
        
        if(secim!=7){
        while(secim!=7){
            
        switch(secim){
            
            case 0: 
                System.out.println("[0] ---> Acil Hasta Ekle");
                System.out.println("[1] ---> Acil Hasta Sil");
                System.out.print("Seciminiz : ");
                int esacil = input.nextInt();
                if(esacil==0){
                    int id;               
                    int durum=0;
                    
                    for (int i = 0; i < hasta.HastaID.size(); i++) {                        
                        idler.add(hasta.HastaID.get(i));                        
                    }
                    for (int i = 0; i < acil.HastaID.size(); i++) {
                        idler.add(acil.HastaID.get(i));                        
                    }
                    
                                     
                    do{
                        System.out.print("Hasta ID Giriniz : ");
                        id = input.nextInt();
                        for (int i = 0; i < idler.size(); i++) {
                            
                            if(id==(Integer)idler.get(i)){
                                System.out.println("ID mevcut! lütfen farkli bir ID giriniz");
                                durum=1;
                                break;
                                
                            }                            
                            else{
                                durum=0;
                            }
                        }                                       
                       
                    }while(durum==1);
                    
                    acil.HastaEkle(id);
                }
                else if(esacil==1){
                    System.out.println("\n");
                    acil.HastaListele();
                    System.out.println("\n");
                    acil.HastaSil();
                }
                    
                else
                    System.out.println("Yanlis secim yaptiniz!");
                break;
            case 1:
                System.out.println("[0] ---> Normal Hasta Ekle");
                System.out.println("[1] ---> Normal Hasta Sil");
                System.out.print("Seciminiz : ");
                int esnormal = input.nextInt();
                
                if(esnormal==0){
                    int id;               
                    int durum=0;
                    
                    for (int i = 0; i < hasta.HastaID.size(); i++) {                        
                        idler.add(hasta.HastaID.get(i));                        
                    }
                    for (int i = 0; i < acil.HastaID.size(); i++) {
                        idler.add(acil.HastaID.get(i));                        
                    }
                    
                    do{
                        System.out.print("Hasta ID Giriniz : ");
                        id = input.nextInt();
                        for (int i = 0; i < idler.size(); i++) {
                            if(id==(Integer)idler.get(i)){
                                System.out.println("ID mevcut! lütfen farkli bir ID giriniz");
                                durum=1; 
                                break;
                            }
                            else
                                durum=0;
                        }                                       
                    
                    }while(durum==1);
                    
                    hasta.HastaEkle(id);
        }
                else if(esnormal==1){
                    System.out.println("\n");
                    hasta.HastaListele();
                    System.out.println("\n");
                    hasta.HastaSil();
                }
                else
                    System.out.println("Yanlis secim yaptiniz!");
                break;
                
            case 2:
                System.out.println("[0] ---> Acil Hasta Listele");
                System.out.println("[1] ---> Normal Hasta Listele");
                System.out.print("Seciminiz : ");
                int lsecim = input.nextInt();
                if(lsecim == 0)
                    acil.HastaListele();
                else if(lsecim == 1)
                    hasta.HastaListele();
                else
                    System.out.println("Yanlis secim yaptiniz!");
                break;
                
            case 3:
                System.out.println("[0] ---> ID numarasina gore ara");
                System.out.println("[1] ---> Isim soyisime gore ara ");
                System.out.print("Seciminiz : ");
                int sec = input.nextInt();
                
                if(sec == 0){
                    System.out.println("ID numarasi giriniz : ");
                    int id = input.nextInt();
                    if(hasta.HastaID.indexOf(id)==-1 && acil.HastaID.indexOf(id)==-1)
                        System.out.println("Hasta Bulunamadi!");
                    else if(hasta.HastaID.indexOf(id)!=-1 && acil.HastaID.indexOf(id)==-1){
                        System.out.println("Hasta Normal Hastalar Bolumunde");
                        hasta.HastaKontrol(id);
                        
                    }
                    else if(hasta.HastaID.indexOf(id)==-1 && acil.HastaID.indexOf(id)!=-1){
                        System.out.println("Hasta Acil Hastalar Bolumunde");
                        acil.HastaKontrol(id);
                    }
                    
                }
                else if(sec == 1){
                    
                    System.out.println("Ad Soyad giriniz : ");
                    input.nextLine();
                    String adsoyad = input.nextLine();
                    if(hasta.AdSoyadlar.indexOf(adsoyad)==-1 && acil.AdSoyadlar.indexOf(adsoyad)==-1)
                        System.out.println("Hasta Bulunamadi!");
                    else if(hasta.AdSoyadlar.indexOf(adsoyad)!=-1 && acil.AdSoyadlar.indexOf(adsoyad)==-1){
                        System.out.println("Hasta Normal Hastalar Bolumunde");
                        hasta.HastaKontrol(adsoyad);
                    }
                    else if(hasta.AdSoyadlar.indexOf(adsoyad)==-1 && acil.AdSoyadlar.indexOf(adsoyad)!=-1){
                        System.out.println("Hasta Acil Hastalar Bolumunde");
                        acil.HastaKontrol(adsoyad);
                    }
                    else{
                        
                        System.out.println("Ayni isimde her iki bolumde de hasta mevcut!\nAcil Hastalar:");
                        acil.HastaKontrol(adsoyad);
                        System.out.println("-------------------------\nNormal Hastalar : ");
                        hasta.HastaKontrol(adsoyad);                       
                        
                    }                      
                    
                    
                }
                else
                    System.out.println("Yanlis secim yaptiniz!");
                break;
            case 4:
                stokislem.StokDurumuGoster();
                break;
            case 5:                
                stokislem.KanEkle();
                break;            
            case 6:
                System.out.println("\n[0] ---> Acil Hasta");
                System.out.println("[1] ---> Normal Hasta");
                System.out.println("Seciminiz : ");
                int hsecim = input.nextInt();
                if(hsecim==0){
                    acil.HastaListele();
                    System.out.print("\nHasta sira no seciniz : ");
                    int indis = input.nextInt();                    
                    String kan = (String)(acil.HastaKanGrubu.get(indis));
                    stokislem.KanKullan(6, kan);                    
                }
                else if(hsecim==1){
                    hasta.HastaListele();
                    System.out.print("\nHasta sira no seciniz : ");
                    int indis = input.nextInt();
                    String kan = (String)(hasta.HastaKanGrubu.get(indis));
                    stokislem.KanKullan(3, kan);  
                }                                    
                    
                else
                    System.out.println("Yanlis secim! Tekrar deneyin...");
                
                break;
            case 7:
                Cikis();
                break;
            
            default:
                System.out.println("Yanlis secim yaptiniz!");
                
                
                
        }
        
        TimeUnit.SECONDS.sleep(2);         
        stokislem.uyari();
        secim = MenuGetir();
        if(secim==7)
            Cikis();
    }               
                             
        
        }
        else
            Cikis();
        
        
    }
    
    static int MenuGetir(){
        
        Scanner input = new Scanner(System.in);
     
        System.out.println("[0] ---> Acil Hasta Ekle/Sil");        
        System.out.println("[1] ---> Normal Hasta Ekle/Sil");                
        System.out.println("[2] ---> Hastalari Listele");
        System.out.println("[3] ---> Hasta Arama");
        System.out.println("[4] ---> Stok Durumu Ogren");
        System.out.println("[5] ---> Kan Ekle");
        System.out.println("[6] ---> Kan Kullan");
        System.out.println("[7] ---> Cikis");
        System.out.print("\nSeciminiz Nedir : ");
        int secim = input.nextInt();
        return secim;        
        
    }
    static void Cikis(){
        
        System.out.println("Bizi Tercih Ettiginiz Icin Tesekkur Ederiz...");
        
    }
   
    
}

  