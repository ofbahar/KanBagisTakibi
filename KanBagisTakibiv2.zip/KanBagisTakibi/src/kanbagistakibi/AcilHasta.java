/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package kanbagistakibi;

/**
 *
 * @author ofbahar
 */
public class AcilHasta extends Hastalar {
    
    @Override
    void ilkHastalar() {
        
       setilkHastaisim("Steve Jobs");
       setilkHastaID(0);
       setilkHastaKanGrubu("Arh-");
       setilkHastaYas(64);
       
       this.AdSoyadlar.add(getilkHastaisim());       
       this.HastaID.add(getilkHastaID());
       this.HastaKanGrubu.add(getilkHastaKanGrubu());
       this.HastaYas.add(getilkHastaYas());
       
       setilkHastaisim("Bill Gates");
       setilkHastaID(1);
       setilkHastaKanGrubu("ABrh+");
       setilkHastaYas(64);
       
       this.AdSoyadlar.add(getilkHastaisim());
       this.HastaID.add(getilkHastaID());
       this.HastaKanGrubu.add(getilkHastaKanGrubu());
       this.HastaYas.add(getilkHastaYas());
        
    } 
      
}
   

    
    
    
    
    

