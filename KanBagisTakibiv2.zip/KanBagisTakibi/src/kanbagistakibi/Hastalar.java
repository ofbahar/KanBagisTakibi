/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package kanbagistakibi;
import java.util.ArrayList;
import java.util.Scanner;



/**
 *
 * @author ofbahar
 */

public class Hastalar {
    
    private String ilkHastaisim;
    private String ilkHastaKanGrubu;
    private int ilkHastaYas;
    private int ilkHastaID; 
    
   /*void ilkHastalar(){
       
       this.AdSoyadlar.add("Ömer Faruk Bahar");
       this.HastaID.add(2);
       this.HastaKanGrubu.add("Arh+");
       this.HastaYas.add(20);
       
       this.AdSoyadlar.add("Linus Torvalds");
       this.HastaID.add(3);
       this.HastaKanGrubu.add("0rh+");
       this.HastaYas.add(49);
       
       
   }*/
    
    Scanner input = new Scanner(System.in);
    KanGrupStok stokislem = new KanGrupStok();
    
    
    ArrayList AdSoyadlar = new ArrayList();    
    ArrayList HastaKanGrubu = new ArrayList();
    ArrayList HastaYas = new ArrayList();
    ArrayList HastaID = new ArrayList();
    ArrayList bulunanindis = new ArrayList();
        
    void HastaKontrol(int id){
                    
            for (int i = 0; i < this.HastaID.size(); i++) {
               
               if(id==(Integer)this.HastaID.get(i))              
                   this.bulunanindis.add(i);
                 
            }
           
            for (int i = 0;i < this.bulunanindis.size(); i++) {
                   
                   int indis = (Integer)this.bulunanindis.get(i);
                   System.out.format("[%d] ---> ID : %d - Ad Soyad : %s - Kan Grubu : %s - Yas : %d\n",i,this.HastaID.get(indis),this.AdSoyadlar.get(indis),this.HastaKanGrubu.get(indis),this.HastaYas.get(indis));
                   
               }                   
            
            bulunanindis.clear();
        }
    
    void HastaKontrol(String isim){
            
            
           for (int i = 0; i < this.AdSoyadlar.size(); i++) {
               
               if(isim == null ? String.valueOf(this.AdSoyadlar.get(i)) == null : isim.equals(String.valueOf(this.AdSoyadlar.get(i))))          
                   this.bulunanindis.add(i);
                   
                 
            }
           
            for (int i = 0;i < this.bulunanindis.size(); i++) {
                   
                   int indis = (Integer)this.bulunanindis.get(i);
                   System.out.format("[%d] ---> ID : %d - Ad Soyad : %s - Kan Grubu : %s - Yas : %d\n",i,this.HastaID.get(indis),this.AdSoyadlar.get(indis),this.HastaKanGrubu.get(indis),this.HastaYas.get(indis));
                   
               }
                                  
            bulunanindis.clear();
        }
        
    void HastaListele(){
        
        for(int i=0;i<this.HastaID.size();i++){            
            
            System.out.format("[%d] ---> ID : %d - Ad Soyad : %s - Kan Grubu : %s - Yas : %d\n",i,this.HastaID.get(i),this.AdSoyadlar.get(i),this.HastaKanGrubu.get(i),this.HastaYas.get(i));
        }
        
        
    }
    
    void HastaEkle(int id){
        
                System.out.print("Hasta Ad Soyad Giriniz : ");
                String isim = input.nextLine();                
                System.out.println("\n");
                int indis = KanGrubuMenu();
                String kan = stokislem.kanGruplari[indis];
                System.out.print("Hasta Yasi Giriniz : ");
                int yas = input.nextInt();
        
                
        this.HastaID.add(id);
        this.AdSoyadlar.add(isim);
        this.HastaYas.add(yas);
        this.HastaKanGrubu.add(kan);
        
        System.out.println("Hasta Eklendi!");
        
    
    }
    
    void HastaSil(){
        
        
        System.out.print("Hasta ID giriniz : ");
        int id = input.nextInt();        
        int indis = HastaID.indexOf(id);
        if (indis == -1)
            System.out.println("Hasta Bulunamadi");
        else{
            
            this.HastaID.remove(indis);
            this.AdSoyadlar.remove(indis);
            this.HastaYas.remove(indis);
            this.HastaKanGrubu.remove(indis);
            
            System.out.println("Silme islemi Basariyla Tamamlandi!");
            
        }
            
    }
            
    
    
    int KanGrubuMenu(){
        
       
        System.out.println("[0] ---> Arh+");
        System.out.println("[1] ---> Brh+");
        System.out.println("[2] ---> ABrh+");
        System.out.println("[3] ---> 0rh+");
        System.out.println("[4] ---> Arh-");
        System.out.println("[5] ---> Brh-");
        System.out.println("[6] ---> ABrh-");
        System.out.println("[7] ---> 0rh-");
        System.out.println("\nKan Grubu Seciniz : ");
        
        return input.nextInt();
        
    }
    
    void KanKullan(){
        
        System.out.println("Hangi hasta icin kan kullanilacak : \n");
        HastaListele();
        System.out.println("\nHasta sira no seciniz : ");
        int indis = input.nextInt();
        String kan = (String)(this.HastaKanGrubu.get(indis));
        
        stokislem.KanKullan(3, kan);
        
        
        
    }
    
    void setilkHastaisim(String isim){
     
        this.ilkHastaisim = isim;
    }
    
    String getilkHastaisim(){ 
        
        return this.ilkHastaisim;
    }
    
    void setilkHastaKanGrubu(String kan){
     
        this.ilkHastaKanGrubu = kan;
    }
    
    String getilkHastaKanGrubu(){
        
        return this.ilkHastaKanGrubu;
    }
    
     void setilkHastaYas(int yas){
     
        this.ilkHastaYas = yas;
    }
    
    int getilkHastaYas(){ 
        
        return this.ilkHastaYas;
    }
    
     void setilkHastaID(int id){
     
        this.ilkHastaID = id;
    }
    
    int getilkHastaID(){ 
        
        return this.ilkHastaID;
    }
    
    void ilkHastalar(){
       
       setilkHastaisim("Ömer Faruk Bahar");
       setilkHastaID(2);
       setilkHastaKanGrubu("Arh+");
       setilkHastaYas(19);
       
       this.AdSoyadlar.add(getilkHastaisim());       
       this.HastaID.add(getilkHastaID());
       this.HastaKanGrubu.add(getilkHastaKanGrubu());
       this.HastaYas.add(getilkHastaYas());
       
       setilkHastaisim("Linus Torvalds");
       setilkHastaID(3);
       setilkHastaKanGrubu("0rh+");
       setilkHastaYas(49);
       
       this.AdSoyadlar.add(getilkHastaisim());
       this.HastaID.add(getilkHastaID());
       this.HastaKanGrubu.add(getilkHastaKanGrubu());
       this.HastaYas.add(getilkHastaYas());
       
       
   }

}
